// server/index.js — VPS-ready server with static site + webhook endpoints
const express = require('express');
const path = require('path');
const fetch = require('node-fetch');
const crypto = require('crypto');

const app = express();
app.use(express.json({ type:'*/*' })); // raw JSON
app.use('/', express.static(path.join(__dirname, 'public')));

// Utilities
function requireEnv(keys){
  const missing = keys.filter(k=> !process.env[k]);
  if(missing.length) throw new Error('Missing env: '+missing.join(', '));
}
function hmacVerify(rawBody, signature, secret){
  const h = crypto.createHmac('sha256', secret).update(rawBody, 'utf8').digest('hex');
  return h === signature;
}

// WhatsApp notify
async function sendWhatsApp({ to, text }){
  try{
    const token = process.env.WHATSAPP_TOKEN;
    const phoneId = process.env.WHATSAPP_PHONE_ID;
    const recipient = to || process.env.WHATSAPP_TO;
    if(!token || !phoneId || !recipient) return;
    const res = await fetch(`https://graph.facebook.com/v21.0/${phoneId}/messages`, {
      method:'POST',
      headers:{ 'Authorization':`Bearer ${token}`, 'Content-Type':'application/json' },
      body: JSON.stringify({ messaging_product:'whatsapp', to: recipient.replace(/\D/g,''), type:'text', text:{ body: text.slice(0,4000) } })
    });
    const data = await res.json();
    console.log('[WA]', data);
  }catch(e){ console.error('[WA] error', e); }
}

// Binance withdraw
async function binanceWithdrawUSDT({ amountUSDT, order_id }){
  requireEnv(['BINANCE_API_KEY','BINANCE_API_SECRET','USDT_DEST_ADDRESS','USDT_NETWORK']);
  const apiKey = process.env.BINANCE_API_KEY;
  const secret = process.env.BINANCE_API_SECRET;
  const dest = process.env.USDT_DEST_ADDRESS;
  const network = process.env.USDT_NETWORK;
  const timestamp = Date.now();
  const params = new URLSearchParams({
    coin:'USDT', address:dest, network, amount: amountUSDT.toFixed(2), withdrawOrderId: order_id, timestamp: String(timestamp)
  });
  const signature = crypto.createHmac('sha256', secret).update(params.toString()).digest('hex');
  params.append('signature', signature);
  const res = await fetch('https://api.binance.com/sapi/v1/capital/withdraw/apply', {
    method:'POST',
    headers:{ 'X-MBX-APIKEY': apiKey, 'Content-Type':'application/x-www-form-urlencoded' },
    body: params.toString()
  });
  const data = await res.json();
  if(!res.ok) throw new Error('Binance withdraw failed: '+JSON.stringify(data));
  return data;
}

function kwdToUsdt(kwd){
  const rate = parseFloat(process.env.KWD_USD_RATE || '3.25');
  return kwd * rate;
}

// TAP webhook
app.post('/webhook/tap', async (req, res)=>{
  try{
    if(process.env.TAP_WEBHOOK_SECRET){
      const sig = req.headers['tap-signature'] || req.headers['Tap-Signature'];
      const raw = JSON.stringify(req.body||{});
      if(!sig || !hmacVerify(raw, sig, process.env.TAP_WEBHOOK_SECRET)) return res.status(400).json({error:'Invalid signature'});
    }
    const payload = req.body || {};
    const status = (payload?.status||'').toUpperCase();
    const amountKWD = Number(payload?.amount || payload?.transaction?.amount) || 0;
    const order_id = payload?.metadata?.order_id || payload?.reference?.order || payload?.id;
    await sendWhatsApp({ text: `DR.iPhone\nTAP Webhook\nالحالة: ${status}\nOrder: ${order_id}\nالمبلغ: ${amountKWD} KWD` });
    if(['CAPTURED','SUCCESS','AUTHORIZED'].includes(status)){
      const usdt = kwdToUsdt(amountKWD);
      try{
        const w = await binanceWithdrawUSDT({ amountUSDT: usdt, order_id });
        await sendWhatsApp({ text: `سحب USDT مبدوء ✅\nOrder: ${order_id}\nUSDT≈ ${usdt.toFixed(2)}` });
        return res.json({received:true, payout:true, withdraw:w});
      }catch(e){
        await sendWhatsApp({ text: `⚠️ فشل سحب USDT\nOrder: ${order_id}\n${e.message}` });
        return res.status(500).json({received:true, payout:false, error:e.message});
      }
    }
    return res.json({received:true, status});
  }catch(e){
    console.error(e);
    await sendWhatsApp({ text: `⚠️ Webhook Error: ${e.message}` });
    return res.status(500).json({error:e.message});
  }
});

// Health
app.get('/health', (_, res)=> res.json({ok:true, t:Date.now()}));

const PORT = process.env.PORT || 8080;
app.listen(PORT, ()=> console.log('Server on', PORT));
