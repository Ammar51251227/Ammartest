# تشغيل على خادم ثابت (VPS)

1) ثبّت Node.js 20 و Nginx.
2) انسخ مجلد `server/` إلى `/opt/driphone`، ثم:
   ```bash
   cd /opt/driphone
   npm i --only=production
   # ضع المتغيرات في /etc/driphone.env (BINANCE_* , TAP_* , WHATSAPP_* ...)
   sudo cp driphone.service.sample /etc/systemd/system/driphone.service
   sudo systemctl daemon-reload
   sudo systemctl enable --now driphone
   ```
3) ضع `nginx.conf.sample` في `/etc/nginx/sites-available/driphone` ثم:
   ```bash
   sudo ln -s /etc/nginx/sites-available/driphone /etc/nginx/sites-enabled/driphone
   sudo nginx -t && sudo systemctl reload nginx
   ```
4) تأكد من فتح المنفذ 80/443 وإضافة شهادة SSL عبر certbot.
