// netlify/functions/ping.js
exports.handler = async () => ({ statusCode: 200, body: JSON.stringify({ ok: true, t: Date.now() }) });
