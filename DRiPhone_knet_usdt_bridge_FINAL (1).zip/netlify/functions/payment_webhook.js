// netlify/functions/payment_webhook.js
// Finalized Webhook: verifies payment, logs details, triggers USDT payout (Binance signed), and sends WhatsApp alerts.

const fetch = require('node-fetch');
const crypto = require('crypto');
const { json, requireEnv, hmacVerify } = require('./_utils');

// --- WhatsApp Cloud API notification
async function sendWhatsApp({ to, text }){
  try{
    const token = process.env.WHATSAPP_TOKEN;
    const phoneId = process.env.WHATSAPP_PHONE_ID;
    const recipient = to || process.env.WHATSAPP_TO;
    if(!token || !phoneId || !recipient){
      console.log('[WA] Skipped (missing env).');
      return { ok:false, skipped:true };
    }
    const res = await fetch(`https://graph.facebook.com/v21.0/${phoneId}/messages`, {
      method:'POST',
      headers:{ 'Authorization':`Bearer ${token}`, 'Content-Type':'application/json' },
      body: JSON.stringify({
        messaging_product:'whatsapp',
        to: recipient.replace(/\D/g,''), // E.164
        type:'text',
        text:{ body: text.slice(0, 4000) }
      })
    });
    const data = await res.json();
    console.log('[WA] Response:', data);
    return { ok: res.ok, data };
  }catch(err){
    console.error('[WA] Error:', err);
    return { ok:false, error:err.message };
  }
}

// --- Binance signed withdrawal
async function binanceWithdrawUSDT({ amountUSDT, order_id }){
  requireEnv(['BINANCE_API_KEY','BINANCE_API_SECRET','USDT_DEST_ADDRESS','USDT_NETWORK']);
  const apiKey = process.env.BINANCE_API_KEY;
  const secret = process.env.BINANCE_API_SECRET;
  const dest = process.env.USDT_DEST_ADDRESS;
  const network = process.env.USDT_NETWORK; // 'ETH' for ERC20 on Binance

  const timestamp = Date.now();
  const params = new URLSearchParams({
    coin: 'USDT',
    address: dest,
    network,
    amount: amountUSDT.toFixed(2),
    withdrawOrderId: order_id,
    timestamp: String(timestamp)
  });

  const signature = crypto.createHmac('sha256', secret).update(params.toString()).digest('hex');
  params.append('signature', signature);

  const res = await fetch('https://api.binance.com/sapi/v1/capital/withdraw/apply', {
    method:'POST',
    headers:{
      'X-MBX-APIKEY': apiKey,
      'Content-Type':'application/x-www-form-urlencoded'
    },
    body: params.toString()
  });
  const data = await res.json();
  console.log('[Binance] Withdraw response:', data);
  if(!res.ok){
    throw new Error('Binance withdraw failed: '+JSON.stringify(data));
  }
  return data;
}

// --- Helper: convert KWD->USDT approx via env rate (can be replaced with live FX later)
function kwdToUsdt(kwd){
  const rate = parseFloat(process.env.KWD_USD_RATE || '3.25'); // 1 KWD ≈ 3.25 USD
  const usd = kwd * rate;
  return usd; // assume 1 USDT ≈ 1 USD
}

exports.handler = async (event, context) => {
  if(event.httpMethod !== 'POST') return json({statusCode:405},405,{error:'Method not allowed'});
  const provider = (process.env.PAYMENT_PROVIDER||'TAP').toUpperCase();

  try{
    if(provider === 'TAP'){
      // Verify signature if configured
      if(process.env.TAP_WEBHOOK_SECRET){
        const sig = event.headers['tap-signature'] || event.headers['Tap-Signature'];
        if(!sig || !hmacVerify(event.body, sig, process.env.TAP_WEBHOOK_SECRET)){
          console.warn('[TAP] invalid signature');
          return json({statusCode:400},400,{error:'Invalid signature'});
        }
      }
      const payload = JSON.parse(event.body||'{}');
      console.log('[TAP] Webhook payload:', payload);

      const status = (payload?.status||'').toUpperCase();
      const amountKWD = Number(payload?.amount || payload?.transaction?.amount) || 0;
      const order_id = payload?.metadata?.order_id || payload?.reference?.order || payload?.id;

      // Notify received
      await sendWhatsApp({ to: process.env.WHATSAPP_TO, text: `DR.iPhone\nاستلمنا Webhook من TAP\nالحالة: ${status}\nالطلب: ${order_id}\nالمبلغ: ${amountKWD} KWD` });

      if(status === 'CAPTURED' || status === 'SUCCESS' || status === 'AUTHORIZED'){
        // Convert & withdraw
        const usdt = kwdToUsdt(amountKWD);
        let withdraw = null;
        try{
          withdraw = await binanceWithdrawUSDT({ amountUSDT: usdt, order_id });
          await sendWhatsApp({ to: process.env.WHATSAPP_TO, text: `دفع KNET ناجح ✅\nOrder: ${order_id}\nKWD: ${amountKWD}\nUSDT (تقريبي): ${usdt.toFixed(2)}\nتم إرسال طلب سحب عبر Binance.` });
        }catch(e){
          console.error('[Binance] Error', e);
          await sendWhatsApp({ to: process.env.WHATSAPP_TO, text: `⚠️ فشل السحب من Binance\nOrder: ${order_id}\n${e.message}` });
          return json({statusCode:500},500,{received:true, payout:false, error:e.message});
        }
        return json({statusCode:200},200,{received:true, payout:true, withdraw});
      }
      return json({statusCode:200},200,{received:true, status});
    }

    if(provider === 'MYFATOORAH'){
      requireEnv(['MYFATOORAH_TOKEN']);
      const body = JSON.parse(event.body||'{}');
      console.log('[MF] Webhook body:', body);
      const PaymentId = body?.PaymentId || body?.paymentId;
      const InvoiceId = body?.InvoiceId || body?.invoiceId;
      const enquiryRes = await fetch('https://api.myfatoorah.com/v2/getPaymentStatus', {
        method:'POST',
        headers:{ 'Authorization':'Bearer '+process.env.MYFATOORAH_TOKEN, 'Content-Type':'application/json' },
        body: JSON.stringify({ Key: PaymentId || InvoiceId, KeyType: PaymentId ? 'PaymentId' : 'InvoiceId' })
      });
      const data = await enquiryRes.json();
      console.log('[MF] Enquiry:', data);
      const success = data?.Data?.InvoiceStatus === 'Paid';
      const amountKWD = Number(data?.Data?.InvoiceValue||0);
      const order_id = data?.Data?.CustomerReference || data?.Data?.InvoiceId;
      await sendWhatsApp({ to: process.env.WHATSAPP_TO, text: `DR.iPhone\nاستلمنا Webhook من MyFatoorah\nالحالة: ${data?.Data?.InvoiceStatus}\nالطلب: ${order_id}\nالمبلغ: ${amountKWD} KWD` });
      if(success){
        const usdt = kwdToUsdt(amountKWD);
        let withdraw = null;
        try{
          withdraw = await binanceWithdrawUSDT({ amountUSDT: usdt, order_id });
          await sendWhatsApp({ to: process.env.WHATSAPP_TO, text: `دفع ناجح ✅\nOrder: ${order_id}\nKWD: ${amountKWD}\nUSDT (تقريبي): ${usdt.toFixed(2)}\nتم إرسال طلب سحب عبر Binance.` });
        }catch(e){
          console.error('[Binance] Error', e);
          await sendWhatsApp({ to: process.env.WHATSAPP_TO, text: `⚠️ فشل السحب من Binance\nOrder: ${order_id}\n${e.message}` });
          return json({statusCode:500},500,{received:true, payout:false, error:e.message});
        }
        return json({statusCode:200},200,{received:true, payout:true, withdraw});
      }
      return json({statusCode:200},200,{received:true, status:data?.Data?.InvoiceStatus});
    }

    return json({statusCode:400},400,{error:'Unsupported provider'});
  }catch(err){
    console.error('[Webhook] Error', err);
    await sendWhatsApp({ to: process.env.WHATSAPP_TO, text: `⚠️ Webhook Error: ${err.message}` });
    return json({statusCode:500},500,{error:err.message});
  }
};
