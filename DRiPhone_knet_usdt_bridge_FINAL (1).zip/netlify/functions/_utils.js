// netlify/functions/_utils.js
const crypto = require('crypto');

function json(res, status, data){ 
  res.statusCode = status; 
  res.setHeader('Content-Type','application/json'); 
  res.end(JSON.stringify(data)); 
}

function requireEnv(keys){
  const missing = keys.filter(k=> !process.env[k]);
  if(missing.length) throw new Error('Missing env: '+missing.join(', '));
}

function hmacVerify(rawBody, signature, secret){
  const h = crypto.createHmac('sha256', secret).update(rawBody, 'utf8').digest('hex');
  return h === signature;
}

module.exports = { json, requireEnv, hmacVerify };
