// netlify/functions/create_knet_session.js
// Creates a KNET checkout session via your PSP, returns {redirect_url, provider_ref, order_id}
const fetch = require('node-fetch');
const { json, requireEnv } = require('./_utils');

exports.handler = async (event, context) => {
  if(event.httpMethod !== 'POST') return json({statusCode:405},405,{error:'Method not allowed'});
  let body;
  try{ body = JSON.parse(event.body||'{}'); } catch{ return json({statusCode:400},400,{error:'Invalid JSON'}); }
  const { amount, currency, order_id, description, items } = body;
  if(!amount || !currency || !order_id) return json({statusCode:400},400,{error:'amount, currency, order_id required'});

  const provider = (process.env.PAYMENT_PROVIDER||'TAP').toUpperCase();

  try{
    if(provider === 'TAP'){
      // TAP example (see: https://developers.tap.company/docs/knet )
      // NOTE: fill TAP_SECRET_KEY from dashboard; KNET is KWD-only and redirect flow.
      requireEnv(['TAP_SECRET_KEY']);
      const tapRes = await fetch('https://api.tap.company/v2/charges', {
        method:'POST',
        headers:{
          'Authorization':'Bearer '+process.env.TAP_SECRET_KEY,
          'Content-Type':'application/json'
        },
        body: JSON.stringify({
          amount: +amount,
          currency: currency || 'KWD',
          threeDSecure: true,
          save_card: false,
          description: description || order_id,
          statement_descriptor: 'DR.iPhone',
          src: 'src_kw.knet', // KNET source
          redirect: { url: process.env.KNET_RETURN_URL || 'https://example.com/thank-you' },
          metadata: { order_id }
        })
      });
      const data = await tapRes.json();
      if(tapRes.status>=400) throw new Error('Tap error '+tapRes.status+': '+JSON.stringify(data));
      return json({statusCode:200},200,{
        redirect_url: data.transaction && data.transaction.url ? data.transaction.url : (data.redirect && data.redirect.url),
        provider_ref: data.id, order_id
      });
    } else if (provider === 'MYFATOORAH'){
      // MyFatoorah example (see: https://docs.myfatoorah.com/docs/gateway-integration )
      // Create an invoice/payment and get the PaymentURL
      requireEnv(['MYFATOORAH_TOKEN']);
      const initRes = await fetch('https://api.myfatoorah.com/v2/SendPayment', {
        method:'POST',
        headers:{ 'Authorization':'Bearer '+process.env.MYFATOORAH_TOKEN, 'Content-Type':'application/json' },
        body: JSON.stringify({
          CustomerName: 'Customer',
          InvoiceValue: +amount,
          DisplayCurrencyIso: currency || 'KWD',
          CallBackUrl: process.env.KNET_RETURN_URL || 'https://example.com/thank-you',
          ErrorUrl: process.env.KNET_ERROR_URL || 'https://example.com/error',
          Language: 'AR',
          CustomerReference: order_id
        })
      });
      const data = await initRes.json();
      if(initRes.status>=400 || !data?.Data?.InvoiceId) throw new Error('MyFatoorah error '+initRes.status+': '+JSON.stringify(data));
      // KNET will be one of the available methods on the returned page
      return json({statusCode:200},200,{
        redirect_url: data.Data?.PaymentURL,
        provider_ref: data.Data?.InvoiceId,
        order_id
      });
    } else {
      throw new Error('Unsupported PAYMENT_PROVIDER');
    }
  }catch(err){
    console.error(err);
    return json({statusCode:500},500,{error: err.message});
  }
};
