
const fmt = (v, curr) => new Intl.NumberFormat('ar-KW', { style: 'currency', currency: curr || 'KWD' }).format(v);
const qs = (s, el=document)=> el.querySelector(s);
const qsa = (s, el=document)=> [...el.querySelectorAll(s)];
const readJSON = (url)=> fetch(url).then(r=>r.json());

function uid(prefix="ORD"){
  const now = new Date();
  const part = now.toISOString().replace(/[-:TZ.]/g,'').slice(0,14);
  const rnd = Math.floor(Math.random()*1e6).toString().padStart(6,'0');
  return `${prefix}-${part}-${rnd}`;
}
function tpl(strings, ...vals){
  const [s] = strings;
  return (data) => s.replace(/\{(\w+)\}/g, (_,k)=> encodeURIComponent(data[k] ?? ""));
}
function showModal(html){
  const backdrop = qs('#modalBackdrop');
  const modal = qs('#modal');
  modal.innerHTML = html;
  backdrop.style.display = 'flex';
  backdrop.onclick = (e)=>{ if(e.target === backdrop) backdrop.style.display='none'; };
  qsa('[data-close]').forEach(btn=> btn.onclick= ()=> backdrop.style.display='none');
}
function copyText(text){
  navigator.clipboard.writeText(text).then(()=> alert('تم النسخ ✅')).catch(()=> prompt('انسخ يدويًا:', text));
}

let CONFIG = null;
let PRODUCTS = [];
let CART = JSON.parse(localStorage.getItem('cart')||'[]');
function saveCart(){ localStorage.setItem('cart', JSON.stringify(CART)); }
function addToCart(prod){
  const exist = CART.find(i=> i.id === prod.id);
  if(exist){ exist.qty += 1; } else { CART.push({id: prod.id, name: prod.name, price: prod.price, img: prod.img, qty: 1}); }
  renderCart(); saveCart();
}
function removeFromCart(id){ CART = CART.filter(i=> i.id !== id); renderCart(); saveCart(); }
function updateQty(id, delta){ const it = CART.find(i=> i.id === id); if(!it) return; it.qty=Math.max(1, it.qty+delta); renderCart(); saveCart(); }
function cartTotal(){ return CART.reduce((s,i)=> s + i.price*i.qty, 0); }

function renderCart(){
  const box = qs('#cartItems');
  if(CART.length===0){ box.innerHTML = '<div class="notice">السلة فارغة.</div>'; }
  else{
    box.innerHTML = CART.map(i=>`
      <div class="cart-item">
        <img src="${i.img}" alt="${i.name}"/>
        <div style="flex:1">
          <div class="title">${i.name}</div>
          <div class="help">${fmt(i.price, CONFIG.currency)} × ${i.qty}</div>
          <div>
            <button class="btn secondary" onclick="updateQty('${i.id}',1)">+</button>
            <button class="btn secondary" onclick="updateQty('${i.id}',-1)">−</button>
            <button class="btn" style="background:#ef4444;color:white" onclick="removeFromCart('${i.id}')">حذف</button>
          </div>
        </div>
        <div style="font-weight:800">${fmt(i.price*i.qty, CONFIG.currency)}</div>
      </div>`).join('');
  }
  qs('#cartTotal').textContent = fmt(cartTotal(), CONFIG.currency);
}
function renderProducts(list){
  const wrap = qs('#products');
  if(list.length===0){ wrap.innerHTML = '<div class="notice">لا توجد نتائج مطابقة.</div>'; return; }
  wrap.innerHTML = list.map(p=>`
    <article class="card">
      <img src="${p.img}" alt="${p.name}"/>
      <h3>${p.name}</h3>
      <p>${p.desc||''}</p>
      <div class="price">${fmt(p.price, CONFIG.currency)}</div>
      <div class="actions">
        <button class="btn" onclick='addToCart(${JSON.stringify(p)})'>أضف للسلة</button>
        <span class="badge">${p.brand}</span>
      </div>
    </article>`).join('');
}
function payUSDT(){
  if(!CONFIG.crypto?.enabled){ alert('طريقة USDT غير مفعلة.'); return; }
  if(CART.length===0){ alert('أضف منتجات أولًا.'); return; }
  const order_id = uid();
  const amount = cartTotal();
  const desc = `Order ${order_id}`;
  const addr = CONFIG.crypto.address;
  const net = CONFIG.crypto.network || '';
  const asset = CONFIG.crypto.asset || 'USDT';
  const qrSrc = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(addr)}`;
  const msg = `طلب جديد ${order_id}%0Aالمبلغ: ${amount} ${CONFIG.currency}%0Aالدفع: ${asset} ${net}%0Aالسلة: ${CART.map(i=>i.name+'×'+i.qty).join(', ')}`;
  const wa = CONFIG.contact?.whatsapp_number ? `https://wa.me/${CONFIG.contact.whatsapp_number.replace(/[^+\d]/g,'')}/?text=${msg}` : null;
  const tg = CONFIG.contact?.telegram_username ? `https://t.me/${CONFIG.contact.telegram_username}` : null;
  showModal(`
    <h3>الدفع عبر ${asset} (${net})</h3>
    <div class="row">
      <div class="qr"><img src="${qrSrc}" alt="QR"/></div>
      <div>
        <div class="help">أرسل المبلغ الإجمالي ثم أرسل لنا هاش التحويل مع رقم الطلب.</div>
        <label>عنوان المحفظة</label>
        <input class="input" value="${addr}" readonly onclick="this.select()"/>
        <div style="display:flex;gap:8px;margin-top:8px">
          <button class="btn" onclick="copyText('${addr}')">نسخ العنوان</button>
          ${wa ? `<a class="btn secondary" href="${wa}" target="_blank">واتساب</a>`:''}
          ${tg ? `<a class="btn secondary" href="${tg}" target="_blank">تيليجرام</a>`:''}
        </div>
        <div class="help" style="margin-top:8px">رقم الطلب: <b>${order_id}</b></div>
      </div>
    </div>
    <div style="margin-top:12px;display:flex;justify-content:flex-end;gap:8px">
      <button class="btn" data-close>إغلاق</button>
    </div>`);
}
function payKNET(){
  if(!CONFIG.knet?.enabled){ alert('طريقة KNET غير مفعلة.'); return; }
  if(CART.length===0){ alert('أضف منتجات أولًا.'); return; }
  const order_id = uid();
  const amount = cartTotal();
  const desc = `Order ${order_id}`;
  const tmpl = tpl`${CONFIG.knet.payment_url_template}`;
  const url = tmpl({amount, order_id, description: desc});
  showModal(`
    <h3>الانتقال إلى دفع KNET</h3>
    <p class="help">عند الضغط على متابعة سيتم توجيهك إلى صفحة الدفع الخاصة بمزوّدك.</p>
    <div style="display:flex;justify-content:flex-end;gap:8px">
      <a class="btn" href="${url}" target="_blank">متابعة</a>
      <button class="btn secondary" data-close>إلغاء</button>
    </div>
    <div class="help" style="margin-top:10px">رقم الطلب: <b>${order_id}</b> — المبلغ: <b>${fmt(amount, CONFIG.currency)}</b></div>`);
}
async function boot(){
  try{ CONFIG = await readJSON('config.json'); PRODUCTS = await readJSON('products.json'); }
  catch(e){ alert('تعذر تحميل الإعدادات/المنتجات.'); console.error(e); return; }
  qs('#year').textContent = new Date().getFullYear();
  renderProducts(PRODUCTS); renderCart();
  qs('#searchInput').addEventListener('input', e=>{
    const q = e.target.value.trim().toLowerCase();
    const list = PRODUCTS.filter(p=> (p.name+p.brand).toLowerCase().includes(q));
    renderProducts(list);
  });
  qs('#payUSDT').onclick = payUSDT;
  qs('#payKNET').onclick = ()=> (CONFIG.knet?.mode==='server'? payKNET_Server() : payKNET());
}
boot();


// --- Server-backed KNET flow (Netlify Functions) ---
async function payKNET_Server(){
  if(!CONFIG.knet?.enabled){ alert('طريقة KNET غير مفعلة.'); return; }
  if(CART.length===0){ alert('أضف منتجات أولًا.'); return; }
  const order_id = uid();
  const amount = cartTotal();
  const desc = `Order ${order_id}`;
  try{
    const res = await fetch('/.netlify/functions/create_knet_session', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ amount, currency: CONFIG.currency, order_id: order_id, description: desc, items: CART })
    });
    if(!res.ok){ throw new Error('create_knet_session failed'); }
    const data = await res.json();
    if(data.redirect_url){
      window.location.href = data.redirect_url;
    }else{
      throw new Error('No redirect_url from gateway');
    }
  }catch(e){
    console.error(e);
    alert('تعذر فتح صفحة الدفع. تحقق من الإعدادات.');
  }
}
