# DR.iPhone — متجر هواتف جاهز للنشر

نسخة مخصصة باسم **DR.iPhone** مع ألوان وهوية بسيطة وواجهة عربية RTL.
يشمل سلة مشتريات + دفع USDT + زر دفع KNET عبر رابط القالب.

## الإعداد
1) افتح `config.json` وعدّل:
- `knet.payment_url_template`: قالب رابط مزوّد KNET لديك (`{amount}`, `{order_id}`, `{description}`).
- `crypto.address`: عنوان محفظتك الحقيقي على شبكة USDT.
- `contact.whatsapp_number` و `contact.telegram_username` (اختياري).
2) حدّث الأسعار/المنتجات داخل `products.json`.
3) ارفع الملفات كما هي إلى Netlify/Vercel/GitHub Pages.

> هذا القالب لا يؤكد الدفع تلقائيًا. لدمج Webhook وتأكيد تلقائي سنحتاج إضافة خادم بسيط.
