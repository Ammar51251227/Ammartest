import React from 'react';
import { Shield, Phone, Mail, Globe, Clock } from 'lucide-react';

interface FooterProps {
  isRTL: boolean;
}

const Footer: React.FC<FooterProps> = ({ isRTL }) => {
  return (
    <footer className="bg-gray-800 text-white mt-12">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-2 rtl:space-x-reverse mb-4">
              <Shield className="h-6 w-6 text-blue-400" />
              <h3 className="text-lg font-semibold">
                {isRTL ? 'كي نت' : 'KNET'}
              </h3>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">
              {isRTL 
                ? 'نظام الدفع الإلكتروني الآمن المعتمد من بنك الكويت المركزي. جميع المعاملات محمية بأعلى معايير الأمان والتشفير.'
                : 'Secure electronic payment system approved by the Central Bank of Kuwait. All transactions are protected with the highest security and encryption standards.'
              }
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-blue-400">
              {isRTL ? 'خدمة العملاء' : 'Customer Service'}
            </h4>
            <div className="space-y-3">
              <div className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-gray-300">
                <Phone className="h-4 w-4 text-green-400" />
                <span>1828000</span>
              </div>
              <div className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-gray-300">
                <Mail className="h-4 w-4 text-green-400" />
                <span>support@knet.com.kw</span>
              </div>
              <div className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-gray-300">
                <Clock className="h-4 w-4 text-green-400" />
                <span>{isRTL ? '24 ساعة / 7 أيام' : '24/7 Support'}</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-blue-400">
              {isRTL ? 'الأمان والحماية' : 'Security & Protection'}
            </h4>
            <div className="space-y-2">
              <div className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-gray-300">
                <Shield className="h-4 w-4 text-green-400" />
                <span>{isRTL ? 'تشفير SSL 256-bit' : '256-bit SSL Encryption'}</span>
              </div>
              <div className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-gray-300">
                <Shield className="h-4 w-4 text-green-400" />
                <span>{isRTL ? 'معايير PCI DSS' : 'PCI DSS Compliant'}</span>
              </div>
              <div className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-gray-300">
                <Globe className="h-4 w-4 text-green-400" />
                <span>{isRTL ? 'مراقبة 24/7' : '24/7 Monitoring'}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              {isRTL 
                ? `© ${new Date().getFullYear()} جميع الحقوق محفوظة - بنك الكويت المركزي`
                : `© ${new Date().getFullYear()} All rights reserved - Central Bank of Kuwait`
              }
            </p>
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <span className="text-xs text-gray-500">
                {isRTL ? 'نسخة آمنة 2.1.0' : 'Secure Version 2.1.0'}
              </span>
              <div className="flex items-center space-x-1 rtl:space-x-reverse">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-xs text-green-400">
                  {isRTL ? 'متصل' : 'Online'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;