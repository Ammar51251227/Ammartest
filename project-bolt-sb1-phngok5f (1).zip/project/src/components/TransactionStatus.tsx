import React from 'react';
import { Loader2, Shield, CreditCard } from 'lucide-react';
import { TransactionData } from '../App';

interface TransactionStatusProps {
  transactionData: Partial<TransactionData>;
  isRTL: boolean;
}

const TransactionStatus: React.FC<TransactionStatusProps> = ({ transactionData, isRTL }) => {
  return (
    <div className="bg-white rounded-xl shadow-xl p-8 text-center">
      <div className="flex justify-center mb-6">
        <div className="relative">
          <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center">
            <Loader2 className="h-12 w-12 text-blue-600 animate-spin" />
          </div>
          <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
            <Shield className="h-4 w-4 text-green-600" />
          </div>
        </div>
      </div>

      <h2 className="text-3xl font-bold text-gray-800 mb-4">
        {isRTL ? 'جارِ معالجة المعاملة' : 'Processing Transaction'}
      </h2>
      
      <p className="text-gray-600 mb-8 max-w-md mx-auto">
        {isRTL 
          ? 'يرجى الانتظار أثناء معالجة طلب الدفع الخاص بك. لا تقم بإغلاق هذه النافذة أو الضغط على زر الرجوع.'
          : 'Please wait while we process your payment request. Do not close this window or press the back button.'
        }
      </p>

      <div className="bg-blue-50 rounded-lg p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <span className="text-gray-600">
            {isRTL ? 'رقم المعاملة' : 'Transaction ID'}
          </span>
          <span className="font-mono text-blue-600 font-semibold">
            {transactionData.transactionId}
          </span>
        </div>
        
        <div className="flex items-center justify-between mb-4">
          <span className="text-gray-600">
            {isRTL ? 'المبلغ' : 'Amount'}
          </span>
          <span className="font-bold text-lg text-gray-800">
            {transactionData.amount} {isRTL ? 'د.ك' : 'KWD'}
          </span>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-gray-600">
            {isRTL ? 'البنك' : 'Bank'}
          </span>
          <span className="font-semibold text-gray-800">
            {transactionData.bankCode}
          </span>
        </div>
      </div>

      <div className="flex items-center justify-center space-x-4 rtl:space-x-reverse text-sm text-gray-500">
        <div className="flex items-center space-x-1 rtl:space-x-reverse">
          <CreditCard className="h-4 w-4" />
          <span>{isRTL ? 'دفع آمن' : 'Secure Payment'}</span>
        </div>
        <div className="w-1 h-1 bg-gray-300 rounded-full"></div>
        <div className="flex items-center space-x-1 rtl:space-x-reverse">
          <Shield className="h-4 w-4" />
          <span>{isRTL ? 'محمي بـ SSL' : 'SSL Protected'}</span>
        </div>
      </div>

      <div className="mt-8">
        <div className="flex justify-center space-x-2 rtl:space-x-reverse">
          <div className="w-3 h-3 bg-blue-600 rounded-full animate-bounce"></div>
          <div className="w-3 h-3 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
          <div className="w-3 h-3 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
        </div>
      </div>
    </div>
  );
};

export default TransactionStatus;