import React from 'react';
import { Shield, Globe, Phone } from 'lucide-react';

interface HeaderProps {
  isRTL: boolean;
  onLanguageToggle: () => void;
}

const Header: React.FC<HeaderProps> = ({ isRTL, onLanguageToggle }) => {
  return (
    <header className="bg-white shadow-lg border-b-4 border-blue-600">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Shield className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-blue-800">
                {isRTL ? 'كي نت' : 'KNET'}
              </h1>
            </div>
            <div className="hidden md:flex items-center space-x-1 rtl:space-x-reverse text-sm text-green-600">
              <Shield className="h-4 w-4" />
              <span>{isRTL ? 'آمن ومحمي' : 'Secure & Protected'}</span>
            </div>
          </div>

          <nav className="flex items-center space-x-4 rtl:space-x-reverse">
            <button
              onClick={onLanguageToggle}
              className="flex items-center space-x-1 rtl:space-x-reverse px-3 py-2 rounded-md text-blue-600 hover:bg-blue-50 transition-colors"
            >
              <Globe className="h-4 w-4" />
              <span className="text-sm font-medium">
                {isRTL ? 'English' : 'العربية'}
              </span>
            </button>
            
            <div className="flex items-center space-x-1 rtl:space-x-reverse text-sm text-gray-600">
              <Phone className="h-4 w-4" />
              <span>{isRTL ? 'الدعم: 1828000' : 'Support: 1828000'}</span>
            </div>
          </nav>
        </div>
        
        <div className="border-t border-gray-200">
          <div className="flex items-center justify-center py-2 text-xs text-gray-500 bg-yellow-50">
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span>
                {isRTL 
                  ? 'نظام الدفع الإلكتروني الآمن - جميع الحقوق محفوظة لبنك الكويت المركزي'
                  : 'Secure Electronic Payment System - All rights reserved to Central Bank of Kuwait'
                }
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;