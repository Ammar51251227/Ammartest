import React, { useState } from 'react';
import Header from './components/Header';
import PaymentForm from './components/PaymentForm';
import BankSelection from './components/BankSelection';
import TransactionStatus from './components/TransactionStatus';
import Receipt from './components/Receipt';
import Footer from './components/Footer';

export type TransactionStep = 'bank-selection' | 'payment-form' | 'processing' | 'receipt';

export interface TransactionData {
  bankCode: string;
  cardNumber: string;
  expiryDate: string;
  cvv: string;
  cardHolderName: string;
  amount: number;
  merchantId: string;
  transactionId: string;
}

function App() {
  const [currentStep, setCurrentStep] = useState<TransactionStep>('bank-selection');
  const [transactionData, setTransactionData] = useState<Partial<TransactionData>>({
    amount: 150.500, // KWD
    merchantId: 'MERCHANT_001',
    transactionId: `TXN_${Date.now()}`,
  });
  const [isRTL, setIsRTL] = useState(true);

  const handleStepChange = (step: TransactionStep, data?: Partial<TransactionData>) => {
    if (data) {
      setTransactionData(prev => ({ ...prev, ...data }));
    }
    setCurrentStep(step);
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 ${isRTL ? 'rtl' : 'ltr'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      <Header isRTL={isRTL} onLanguageToggle={() => setIsRTL(!isRTL)} />
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {currentStep === 'bank-selection' && (
            <BankSelection 
              onBankSelect={(bankCode) => handleStepChange('payment-form', { bankCode })}
              isRTL={isRTL}
            />
          )}
          
          {currentStep === 'payment-form' && (
            <PaymentForm 
              transactionData={transactionData}
              onSubmit={(data) => {
                handleStepChange('processing', data);
                // Simulate processing
                setTimeout(() => handleStepChange('receipt'), 3000);
              }}
              onBack={() => handleStepChange('bank-selection')}
              isRTL={isRTL}
            />
          )}
          
          {currentStep === 'processing' && (
            <TransactionStatus 
              transactionData={transactionData}
              isRTL={isRTL}
            />
          )}
          
          {currentStep === 'receipt' && (
            <Receipt 
              transactionData={transactionData as TransactionData}
              onNewTransaction={() => handleStepChange('bank-selection')}
              isRTL={isRTL}
            />
          )}
        </div>
      </main>
      
      <Footer isRTL={isRTL} />
    </div>
  );
}

export default App;